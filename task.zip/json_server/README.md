Type "npm run json-server" to start the json-server.
